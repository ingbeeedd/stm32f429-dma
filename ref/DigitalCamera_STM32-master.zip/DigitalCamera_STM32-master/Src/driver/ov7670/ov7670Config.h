/*
 * ov7670Config.h
 *
 *  Created on: 2017/08/25
 *      Author: take-iwiw
 */

#ifndef OV7670_OV7670CONFIG_H_
#define OV7670_OV7670CONFIG_H_

#define SLAVE_ADDR 0x42


#endif /* OV7670_OV7670CONFIG_H_ */
